# Run from the command line, this creates a preview of the book/site
Rscript -e 'bookdown::serve_book(".", preview=T)'
